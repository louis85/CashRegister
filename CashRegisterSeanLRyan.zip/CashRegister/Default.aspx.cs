﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Globalization;
using System.Reflection;
using System.Resources;
using CashRegister.DataFiles;


namespace CashRegister
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //retreive the register transactions
            List<RegisterTrans> rt = new List<RegisterTrans>();

            rt = RetrieveRegisterTrans();

            string htmltable;

            //build the table for display on default page
            htmltable = "<table><tr><th>Trans. Amount</th><th>Cash Given</th><th></th><th>Change Breakdown</th><tr>";
    

            foreach(var trans in rt)
            {
                htmltable += "<tr><td width='80px' align='right'>" + trans.TransactionAmount.ToString("C", CultureInfo.CurrentCulture) + "</td><td  width='100px' align='right'>" + trans.PaymentAmount.ToString("C", CultureInfo.CurrentCulture) + "</td><td width='20px'>&nbsp;</td><td>" + trans.ChangeBreakdown + "</td><tr>";
                
            }

            htmltable += "</table>";

            displayChange.Text = htmltable;

            //write transactions to a file
            BuildOutputFile(rt);
        }

        public List<RegisterTrans> RetrieveRegisterTrans()
        {
            //open the text file and read each line delimited by comma
            string fileName = "registerTransactions.txt";

            string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"DataFiles\", fileName);

            //string[] lines = System.IO.File.ReadAllLines("C:/Users/Louis85/source/repos/CashRegister/CashRegister/DataFiles/registerTransactions.txt");
            string[] lines = System.IO.File.ReadAllLines(path);


            //init the List that will be created
            List<RegisterTrans> RegTrans = new List<RegisterTrans>();

            foreach (string line in lines)
            {
                var cols = line.Split(',');

                RegisterTrans t = new RegisterTrans();
                t.TransactionAmount = Convert.ToDouble(cols[0]);
                t.PaymentAmount = Convert.ToDouble(cols[1]);

                //if the transaction amount is visible by three
                if ((t.TransactionAmount*100) % 3 == 0)
                {
                    t.divisibleBy3 = true;
                    t.ChangeBreakdown = CalculateRandomChange(t.TransactionAmount, t.PaymentAmount);
                }
                else
                {
                    t.divisibleBy3 = false;
                    t.ChangeBreakdown = CalculateChange(t.TransactionAmount, t.PaymentAmount);
                }

                RegTrans.Add(t);

            }

            return RegTrans;     

        }

        public void BuildOutputFile(List<RegisterTrans> rt)
        {
            //open the text file and read each line delimited by comma
            string fileName = "registerTransactionsOutput.txt";

            string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"DataFiles\", fileName);

            using (StreamWriter file =
                    new StreamWriter(path))
            {
                string line;
                file.WriteLine("Transaction Amount, Payment Amount, ChangeBreakdown");
                file.WriteLine("---------------------------------------------------");
                foreach (var trans in rt)
                {
                    // If the line doesn't contain the word 'Second', write the line to the file.

                    line = trans.TransactionAmount + ", " + trans.PaymentAmount + ", " + trans.ChangeBreakdown;
                    file.WriteLine(line);
                    
                }
            }



        }

        private string CalculateChange(double transactionAmount, double paymentAmount)
        {
            string changeBreakdown = "";
            double changeAmount = paymentAmount - transactionAmount;
            double changeCounter = Math.Round(changeAmount, 2);
            int bill100ctr = 0;
            int bill50ctr = 0;
            int bill20ctr = 0;
            int bill10ctr = 0;
            int bill5ctr = 0;
            int bill1ctr = 0;
            int coin25ctr = 0;
            int coin10ctr = 0;
            int coin5ctr = 0;
            int coin1ctr = 0;

            

            while (changeCounter > 0.00)
            {

                if (changeCounter > 100.00)
                {
                    //enough left for 100 bill
                    changeCounter -= 100.00;
                    changeCounter = Math.Round(changeCounter, 2);
                    bill100ctr += 1;

                }
                else if (changeCounter > 50.00)
                {
                    changeCounter -= 50.00;
                    changeCounter = Math.Round(changeCounter, 2);
                    bill50ctr += 1;
                }
                else if (changeCounter > 20.00)
                {
                    changeCounter -= 20.00;
                    changeCounter = Math.Round(changeCounter, 2);

                    bill20ctr += 1;
                }
                else if (changeCounter > 10.00)
                {
                    changeCounter -= 10.00;
                    changeCounter = Math.Round(changeCounter, 2);

                    bill10ctr += 1;
                }
                else if (changeCounter > 5.00)
                {
                    changeCounter -= 5.00;
                    changeCounter = Math.Round(changeCounter, 2);

                    bill5ctr += 1;
                }
                else if (changeCounter > 1.00)
                {
                    changeCounter -= 1.00;
                    changeCounter = Math.Round(changeCounter, 2);

                    bill1ctr += 1;
                }
                else if (changeCounter > 0.25)
                {
                    changeCounter -= 0.25;
                    changeCounter = Math.Round(changeCounter, 2);

                    coin25ctr += 1;
                }
                else if (changeCounter > 0.10)
                {
                    changeCounter -= 0.1;
                    changeCounter = Math.Round(changeCounter, 2);

                    coin10ctr += 1;
                }
                else if (changeCounter > 0.05)
                {
                    changeCounter -= 0.05;
                    changeCounter = Math.Round(changeCounter, 2);

                    coin5ctr += 1;
                }
                else
                {
                    changeCounter -= 0.01;
                    changeCounter = Math.Round(changeCounter, 2);
                    coin1ctr += 1;
                }

            }

            changeBreakdown = BuildChangeString(bill100ctr, ChangeType.HundredDollarBill) +
                BuildChangeString(bill50ctr, ChangeType.FiftyDollarBill) +
                BuildChangeString(bill20ctr, ChangeType.TwentyDollarBill) +
                BuildChangeString(bill10ctr, ChangeType.TenDollarBill) +
                BuildChangeString(bill5ctr, ChangeType.FiveDollarBill) +
                BuildChangeString(bill1ctr, ChangeType.OneDollarBill) +
                BuildChangeString(coin25ctr, ChangeType.Quarter) +
                BuildChangeString(coin10ctr, ChangeType.Dime) +
                BuildChangeString(coin5ctr, ChangeType.Nickel) +
                BuildChangeString(coin1ctr, ChangeType.Penny);

            return changeBreakdown;
        }

        private string CalculateRandomChange(double transactionAmount, double paymentAmount)
        {
            string changeBreakdown = "";
            double changeAmount = paymentAmount - transactionAmount;
            double changeCounter = Math.Round(changeAmount, 2);
            int bill100ctr = 0;
            int bill50ctr = 0;
            int bill20ctr = 0;
            int bill10ctr = 0;
            int bill5ctr = 0;
            int bill1ctr = 0;
            int coin25ctr = 0;
            int coin10ctr = 0;
            int coin5ctr = 0;
            int coin1ctr = 0;

            Random random = new Random();
            int HighestSettingRandomNumber = 0;
            int billCoinRep;   //this random number will represent which bill/coin is selected 

            while (changeCounter > 0.00999)
            {

                //determine the highest setting for randomization of coins/bills before 
                //selecting one (speeds up the process)          
                if (changeCounter >= 100.00)
                {
                    //enough left for 100 bill
                    HighestSettingRandomNumber = 9;
                }
                else if (changeCounter >= 50.00)
                {
                    HighestSettingRandomNumber = 8;
                }
                else if (changeCounter >= 20.00)
                {
                    HighestSettingRandomNumber = 7;

                }
                else if (changeCounter >= 10.00)
                {
                    HighestSettingRandomNumber = 6;
                }
                else if (changeCounter >= 5.00)
                {
                    HighestSettingRandomNumber = 5;
                }
                else if (changeCounter >= 1.00)
                {
                    HighestSettingRandomNumber = 4;
                }
                else if (changeCounter >= 0.2500)
                {
                    HighestSettingRandomNumber = 3;
                }
                else if (changeCounter >= 0.1000)
                {
                    HighestSettingRandomNumber = 2;
                }
                else if (changeCounter >= 0.0500)
                {
                    HighestSettingRandomNumber = 1;
                }
                else
                {
                    HighestSettingRandomNumber = 0;
                }
           

                //select the random number with your possibly limited choices
                billCoinRep = random.Next(0, HighestSettingRandomNumber + 1);

                switch (billCoinRep)
                {
                    case 9:
                        changeCounter -= 100.00;
                        changeCounter = Math.Round(changeCounter, 2);
                        bill100ctr += 1;
                        break;

                    case 8:
                        changeCounter -= 50.00;
                        changeCounter = Math.Round(changeCounter, 2);
                        bill50ctr += 1;
                        break;

                    case 7:
                        changeCounter -= 20.00;
                        changeCounter = Math.Round(changeCounter, 2);
                        bill20ctr += 1;
                        break;

                    case 6:
                        changeCounter -= 10.00;
                        changeCounter = Math.Round(changeCounter, 2);
                        bill10ctr += 1;
                        break;

                    case 5:
                        changeCounter -= 5.00;
                        changeCounter = Math.Round(changeCounter, 2);
                        bill5ctr += 1;
                        break;

                    case 4:
                        changeCounter -= 1.00;
                        changeCounter = Math.Round(changeCounter, 2);
                        bill1ctr += 1;
                        break;

                    case 3:
                        changeCounter -= 0.2500;
                        changeCounter = Math.Round(changeCounter, 2);
                        coin25ctr += 1;
                        break;

                    case 2:
                        changeCounter -= 0.1000;
                        changeCounter = Math.Round(changeCounter, 2);
                        coin10ctr += 1;
                        break;
                    case 1:
                        changeCounter -= 0.0500;
                        changeCounter = Math.Round(changeCounter, 2);
                        coin5ctr += 1;
                        break;
                    case 0:
                        changeCounter -= 0.0100;
                        changeCounter = Math.Round(changeCounter, 2);
                        coin1ctr += 1;
                        break;
                    default:
                        break;

                }
            }

            changeBreakdown = BuildChangeString(bill100ctr, ChangeType.HundredDollarBill) +
                BuildChangeString(bill50ctr, ChangeType.FiftyDollarBill) +
                BuildChangeString(bill20ctr, ChangeType.TwentyDollarBill) +
                BuildChangeString(bill10ctr, ChangeType.TenDollarBill) +
                BuildChangeString(bill5ctr, ChangeType.FiveDollarBill) +
                BuildChangeString(bill1ctr, ChangeType.OneDollarBill) +
                BuildChangeString(coin25ctr, ChangeType.Quarter) +
                BuildChangeString(coin10ctr, ChangeType.Dime) +
                BuildChangeString(coin5ctr, ChangeType.Nickel) +
                BuildChangeString(coin1ctr, ChangeType.Penny);

            return changeBreakdown;
        }

        public static string BuildChangeString(int number, ChangeType CoinBillType)
        {

            string changeString = "";
                switch (CoinBillType)
                {
                    case ChangeType.Penny:
                    if (number == 1)
                    {
                        changeString = "1 Penny. ";
                    }
                    else if (number > 1)
                    {
                        changeString = number + " Pennies. ";
                    }
                    break;

                    case ChangeType.Nickel:
                    if (number == 1)
                    {
                        changeString = "1 Nickel. ";
                    }
                    else if (number > 1)
                    {
                        changeString = number + " Nickels. ";
                    }
                    break;

                case ChangeType.Dime:
                    if (number == 1)
                    {
                        changeString = "1 Dime. ";
                    }
                    else if (number > 1)
                    {
                        changeString = number + " Dimes. ";
                    }
                    break;

                case ChangeType.Quarter:
                    if (number == 1)
                    {
                        changeString = "1 Quarter. ";
                    }
                    else if (number > 1)
                    {
                        changeString = number + " Quarters. ";
                    }
                    break;

                case ChangeType.OneDollarBill:
                    if (number == 1)
                    {
                        changeString = "1 $1 Bill. ";
                    }
                    else if (number > 1)
                    {
                        changeString = number + " $1 Bills. ";
                    }
                    break;

                case ChangeType.FiveDollarBill:
                    if (number == 1)
                    {
                        changeString = "1 $5 Bill. ";
                    }
                    else if (number > 1)
                    {
                        changeString = number + " $5 Bills. ";
                    }
                    break;

                case ChangeType.TenDollarBill:
                    if (number == 1)
                    {
                        changeString = "1 $10 Bill. ";
                    }
                    else if (number > 1)
                    {
                        changeString = number + " $10 Bills. ";
                    }
                    break;

                case ChangeType.TwentyDollarBill:
                    if (number == 1)
                    {
                        changeString = "1 $20 Bill. ";
                    }
                    else if (number > 1)
                    {
                        changeString = number + " $20 Bills. ";
                    }
                    break;

                case ChangeType.FiftyDollarBill:
                    if (number == 1)
                    {
                        changeString = "1 $50 Bill. ";
                    }
                    else if (number > 1)
                    {
                        changeString = number + " $50 Bills. ";
                    }
                    break;

                case ChangeType.HundredDollarBill:
                    if (number == 1)
                    {
                        changeString = "1 $100 Bill. ";
                    }
                    else if (number > 1)
                    {
                        changeString = number + " $100 Bills. ";
                    }
                    break;

                default:
                        break;

                }

            return changeString;
        }

        public enum ChangeType
        {
            Penny = 0,
            Nickel = 1,
            Dime = 2,
            Quarter = 3,
            OneDollarBill = 4,
            FiveDollarBill = 5,
            TenDollarBill = 6,
            TwentyDollarBill = 7,
            FiftyDollarBill = 8,
            HundredDollarBill = 9

        }
 
    }


}