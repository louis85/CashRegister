﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CashRegister
{
    public class RegisterTrans
    {
        public double TransactionAmount;
        public double PaymentAmount;
        public bool divisibleBy3;
        public string ChangeBreakdown;
    }
}